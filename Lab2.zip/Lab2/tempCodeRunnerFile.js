(e) =>{
  if(e)
  {
    console.error("Error writing output :", e);
  }
  else 
  {
    console.log("JSON object has been created :", filePath);
  }
}